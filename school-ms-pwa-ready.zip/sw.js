// SchoolMS service worker
// Caches the app shell so the app opens instantly and can install as a
// standalone app on Android / iOS / Windows / Mac / Linux.
// Live data (Supabase) always goes over the network — only the shell
// (HTML/CSS/JS/icons) is cached, so records stay accurate and up to date.

const CACHE_NAME = "schoolms-shell-v1";
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const { request } = event;

  // Only handle GET requests for our own origin's app-shell files.
  // Everything else (Supabase API calls, CDN scripts/fonts, etc.)
  // goes straight to the network so data is always fresh.
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) {
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      const networkFetch = fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        })
        .catch(() => cached);

      // Cache-first for instant load / offline support, but refresh in background.
      return cached || networkFetch;
    })
  );
});
