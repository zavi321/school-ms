-- ============================================================================
-- Owner-Controlled School Onboarding (Whitelist + Admin OTP Confirmation)
-- Run this ONCE in Supabase Dashboard → SQL Editor → New Query → Run
-- Run this AFTER setup_rls_multi_tenant.sql (this file builds on it).
-- ============================================================================
-- What this adds:
--   1. Only school emails YOU (the owner) explicitly whitelist are allowed
--      to even attempt Sign Up. Anyone else sees "contact us" instead.
--   2. One Gmail = one school. Supabase's own auth.users table already
--      enforces unique emails, so a whitelisted email can never be used
--      to register a second school account.
--   3. When a school signs up, Supabase sends them a 6-digit confirmation
--      code by email (see the dashboard setup notes at the bottom — you
--      must turn this on manually, it can't be done from SQL/code).
--      The school reads you that code (WhatsApp/call), and you type it
--      into the in-app Admin Panel to activate their account. Until you
--      do this, their account cannot log in.
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 1. Mark yourself (the owner) as admin
-- ---------------------------------------------------------------------------
-- Adds an is_admin flag to profiles. Everyone defaults to false (normal
-- school). Only accounts with is_admin = true see the Admin Panel in the
-- app and are allowed to manage the whitelist below.
alter table public.profiles add column if not exists is_admin boolean not null default false;

-- IMPORTANT: after you sign up your OWN account in the app once, come back
-- here and run this (with YOUR email) to make yourself admin:
--
--   update public.profiles set is_admin = true
--   where id = (select id from auth.users where email = 'YOUR_OWN_EMAIL_HERE');
--
-- Do this manually — it's intentionally not automatic, so nobody else can
-- ever grant themselves admin access.


-- ---------------------------------------------------------------------------
-- 2. The whitelist table
-- ---------------------------------------------------------------------------
create table if not exists public.whitelist_emails (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  status text not null default 'whitelisted',  -- whitelisted -> signup_attempted -> verified
  added_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

alter table public.whitelist_emails enable row level security;

-- Only admins (you) can read/add/edit whitelist rows from the app.
drop policy if exists "whitelist_admin_all" on public.whitelist_emails;
create policy "whitelist_admin_all" on public.whitelist_emails
  for all using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true)
  )
  with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true)
  );


-- ---------------------------------------------------------------------------
-- 3. Public-safe check used by the Sign Up screen
-- ---------------------------------------------------------------------------
-- Anyone can call this to check if an email is allowed to sign up, but it
-- only ever returns true/false — it never exposes the whitelist itself.
create or replace function public.is_email_whitelisted(check_email text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.whitelist_emails
    where lower(email) = lower(check_email)
    and status = 'whitelisted'
  );
$$;
grant execute on function public.is_email_whitelisted(text) to anon, authenticated;

-- Called automatically right after a whitelisted school submits Sign Up,
-- so the Admin Panel shows it as "waiting for your OTP confirmation".
create or replace function public.mark_signup_attempted(check_email text)
returns void
language sql
security definer
set search_path = public
as $$
  update public.whitelist_emails
  set status = 'signup_attempted'
  where lower(email) = lower(check_email) and status = 'whitelisted';
$$;
grant execute on function public.mark_signup_attempted(text) to anon, authenticated;


-- ============================================================================
-- REQUIRED Supabase Dashboard settings (cannot be done from SQL):
--
-- 1. Authentication → Providers → Email → make sure "Confirm email" is ON.
--    This forces every new school to confirm their email with the code
--    before they can log in — this is what makes the OTP step meaningful.
--
-- 2. Authentication → Email Templates → "Confirm signup" → edit the
--    template so it includes {{ .Token }} (the 6-digit code), not just
--    the {{ .ConfirmationURL }} link. Example line to add:
--       Your verification code is: {{ .Token }}
--    This is the code the school will read back to you on WhatsApp.
-- ============================================================================
