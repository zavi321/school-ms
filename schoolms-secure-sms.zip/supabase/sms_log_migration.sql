-- Run this once in Supabase SQL Editor (Dashboard → SQL Editor → New Query)

create table if not exists sms_log (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id),
  student_id uuid,
  mobile text not null,
  message text not null,
  status text not null default 'sent',   -- 'sent' | 'failed' | 'skipped'
  provider_response text,
  created_at timestamptz not null default now()
);

alter table sms_log enable row level security;

-- Each school (owner) can see only their own SMS history
create policy "owner can read own sms_log"
  on sms_log for select
  using (auth.uid() = owner_id);

-- Only the Edge Function (service role) inserts rows — no client-side inserts
create policy "no direct client inserts"
  on sms_log for insert
  with check (false);

-- Helpful for building a monthly billing report per school:
-- select owner_id, count(*) as sms_sent, date_trunc('month', created_at) as month
-- from sms_log where status = 'sent'
-- group by owner_id, month
-- order by month desc;
