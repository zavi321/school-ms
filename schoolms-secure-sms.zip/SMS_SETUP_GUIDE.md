# Secure SMS Setup — Deploy Once, Works For Every School

This replaces the old setup (API key inside the browser) with a secure backend.
Your SendPK key never leaves your server — no school can see it, steal it, or run up your bill on purpose.

## What changed
- `index.html` — no longer contains any SendPK key. It calls your private `send-sms` function instead.
- `supabase/functions/send-sms/index.ts` — the actual SMS-sending code. Runs on Supabase's servers, not in the browser.
- `supabase/sms_log_migration.sql` — creates a table that logs every SMS sent, per school, so you can bill usage later.

## One-time setup (about 10 minutes)

### 1. Install the Supabase CLI (on your own computer)
```
npm install -g supabase
```

### 2. Log in and link your project
```
supabase login
supabase link --project-ref kapbrbuxdaqmuhfxtklq
```
(Your project ref is the part of your Supabase URL before `.supabase.co`.)

### 3. Run the database migration
Open Supabase Dashboard → SQL Editor → New Query → paste the contents of
`supabase/sms_log_migration.sql` → Run.

### 4. Set your SendPK credentials as server secrets (never exposed to anyone)
```
supabase secrets set SENDPK_API_KEY=your_real_sendpk_key
supabase secrets set SENDPK_SENDER=your_approved_sender_id
```

### 5. Deploy the function
```
supabase functions deploy send-sms
```

That's it. Every school that logs into your app will now trigger SMS through your
one central SendPK account, and every message is logged in `sms_log` with their
`owner_id` — so at the end of the month you can run:

```sql
select owner_id, count(*) as sms_sent
from sms_log
where status = 'sent'
group by owner_id
order by sms_sent desc;
```
...to see exactly how many SMS each school used, and bill them accordingly.

## Re-deploying after future changes
Any time you edit `supabase/functions/send-sms/index.ts`, just run
`supabase functions deploy send-sms` again — no need to redo steps 1–4.
