// supabase/functions/send-sms/index.ts
//
// Deploy: supabase functions deploy send-sms
// Secrets (set once, never visible to any school):
//   supabase secrets set SENDPK_API_KEY=your_real_key
//   supabase secrets set SENDPK_SENDER=your_approved_sender_id
//
// Called from the app as: sb.functions.invoke('send-sms', { body: { mobile, message } })
// The caller's Supabase auth session is automatically attached, so this function
// knows exactly which school (owner_id) triggered it — for logging/billing.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const SENDPK_API_KEY = Deno.env.get("SENDPK_API_KEY")!;
const SENDPK_SENDER = Deno.env.get("SENDPK_SENDER")!;

Deno.serve(async (req) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, content-type",
  };
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    // Identify which school (owner) is calling, using their auth token.
    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Not authenticated" }), {
        status: 401, headers: { ...cors, "Content-Type": "application/json" },
      });
    }
    const ownerId = userData.user.id;

    const { mobile, message } = await req.json();
    if (!mobile || !message) {
      return new Response(JSON.stringify({ error: "mobile and message are required" }), {
        status: 400, headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // Admin client (service role) — used to check the school's SMS setting and to log usage.
    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: profile } = await admin
      .from("profiles")
      .select("sms_enabled")
      .eq("id", ownerId)
      .maybeSingle();

    if (profile && profile.sms_enabled === false) {
      await admin.from("sms_log").insert({
        owner_id: ownerId, mobile, message, status: "skipped",
        provider_response: "sms_enabled is false for this school",
      });
      return new Response(JSON.stringify({ status: "skipped" }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    let status = "sent";
    let providerResponse = "";
    try {
      const params = new URLSearchParams({
        api_key: SENDPK_API_KEY, sender: SENDPK_SENDER, mobile, message, format: "json",
      });
      const res = await fetch("https://sendpk.com/api/sms.php?" + params.toString());
      providerResponse = await res.text();
      if (!res.ok) status = "failed";
    } catch (sendErr) {
      status = "failed";
      providerResponse = String(sendErr);
    }

    await admin.from("sms_log").insert({
      owner_id: ownerId, mobile, message, status, provider_response: providerResponse,
    });

    return new Response(JSON.stringify({ status }), {
      headers: { ...cors, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
