-- Run this once in Supabase SQL Editor

alter table profiles add column if not exists sms_enabled boolean not null default true;

-- To turn SMS OFF for a one-time-sale school (no recurring SMS cost for them):
--   update profiles set sms_enabled = false where email = 'school@example.com';

-- To turn SMS back ON later (e.g. if they upgrade to a plan that includes SMS):
--   update profiles set sms_enabled = true where email = 'school@example.com';
