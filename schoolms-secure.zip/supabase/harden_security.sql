-- ============================================================================
-- SECURITY HARDENING — run this ONCE in Supabase Dashboard → SQL Editor
-- ============================================================================
-- Goal: make sure that no school can ever read or change another school's
-- data, even if they open dev tools and try to call the database directly
-- (RLS is enforced by Postgres itself, not by your app's JavaScript — so it
-- can't be bypassed from the browser, no matter how the request is made).
-- ============================================================================

-- ---------- 1. Turn on Row Level Security on every table ----------
alter table students        enable row level security;
alter table teachers         enable row level security;
alter table fee_payments     enable row level security;
alter table salary_payments  enable row level security;
alter table transactions     enable row level security;
alter table admission_register enable row level security;
alter table profiles         enable row level security;
alter table whitelist_emails enable row level security;
alter table sms_log          enable row level security;

-- ---------- 2. Wipe any old/loose policies so we start clean ----------
do $$
declare pol record;
begin
  for pol in
    select schemaname, tablename, policyname from pg_policies
    where tablename in ('students','teachers','fee_payments','salary_payments',
                         'transactions','admission_register','profiles','whitelist_emails','sms_log')
  loop
    execute format('drop policy if exists %I on %I.%I', pol.policyname, pol.schemaname, pol.tablename);
  end loop;
end $$;

-- ---------- 3. Per-school data isolation (owner_id = auth.uid()) ----------
-- Every school can only see/edit/delete rows where owner_id matches their own
-- logged-in user id. This is the core rule that makes multi-tenant data safe.

create policy "own rows only" on students
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "own rows only" on teachers
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "own rows only" on fee_payments
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "own rows only" on salary_payments
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "own rows only" on transactions
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "own rows only" on admission_register
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

-- ---------- 4. Profiles: a user can read/update only their own row ----------
-- Critically: is_admin can NOT be set by the user themselves — only you,
-- via the Supabase dashboard's Table Editor (or service role), should ever
-- flip that flag. We block it from being changed through the app entirely.
create policy "read own profile" on profiles
  for select using (auth.uid() = id);

create policy "update own profile except is_admin" on profiles
  for update using (auth.uid() = id)
  with check (
    auth.uid() = id
    and is_admin is not distinct from (select is_admin from profiles p where p.id = auth.uid())
  );

-- ---------- 5. Whitelist table: schools should never read this directly ----------
-- Only the two controlled RPC functions below may touch it (they run with
-- elevated rights but only expose exactly what's needed — never the full list).
create policy "no direct client access" on whitelist_emails
  for all using (false) with check (false);

-- ---------- 6. SMS log: each school can see only their own usage ----------
create policy "read own sms log" on sms_log
  for select using (auth.uid() = owner_id);
create policy "no direct client inserts" on sms_log
  for insert with check (false); -- only the Edge Function (service role) may insert

-- ---------- 7. Lock down the whitelist RPC functions ----------
-- SECURITY DEFINER functions must pin search_path, or a malicious user could
-- trick them into running against attacker-controlled objects.
alter function is_email_whitelisted(text)   set search_path = public;
alter function mark_signup_attempted(text)  set search_path = public;

-- Only logged-in users may call these two (not anonymous/public):
revoke all on function is_email_whitelisted(text)  from public;
revoke all on function mark_signup_attempted(text) from public;
grant execute on function is_email_whitelisted(text)  to authenticated, anon;
grant execute on function mark_signup_attempted(text) to authenticated, anon;

-- ---------- 8. Double-check: no table should be readable by "anon" beyond auth flow ----------
-- (Supabase's anon key is meant to be public — safety comes entirely from
-- the RLS policies above, not from hiding the key.)
revoke all on students, teachers, fee_payments, salary_payments, transactions,
             admission_register, whitelist_emails from anon;
grant select, insert, update, delete on students, teachers, fee_payments,
             salary_payments, transactions, admission_register to authenticated;

-- ============================================================================
-- After running this: create a fresh test account and confirm you CANNOT see
-- another school's students/fees, even by inspecting network requests.
-- ============================================================================
