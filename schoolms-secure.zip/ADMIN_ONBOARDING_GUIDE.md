# Admin Guide — Onboarding New Schools & Billing

## A. Onboard a new school (after they pay/agree)

1. **Supabase Dashboard → Table Editor → `whitelist_emails`**
   → Insert a row with the school's email (the one they'll sign up with).
2. **Send them this message** (edit as needed):

   > Assalam-o-Alaikum, aapka School Finance & Records account taiyar hai.
   > Link: https://zavi321.github.io/school-ms/
   > Is email se signup karein: [unka email]
   > Mobile par "Add to Home Screen" kar lein taake app jaisa istemal ho.

3. They sign up → app automatically creates their own isolated space (RLS keeps their data separate from every other school).
4. Done — no code, no zip, no setup on their end.

## B. Track who's an active paying customer

Run this in SQL Editor anytime to see everyone who has signed up:
```sql
select email, school_name, created_at
from profiles
order by created_at desc;
```

If you want a simple active/inactive flag (e.g. for schools who stop paying),
add this once:
```sql
alter table profiles add column if not exists subscription_status text default 'active';
-- values you can set manually: 'active', 'suspended', 'trial'
```
Then to cut off a school that stops paying, set their `subscription_status` to
`'suspended'` and add a matching RLS check later (ask me if you want this wired
into the app so suspended accounts see a "contact admin" screen instead of data).

## C. Monthly SMS billing per school
```sql
select p.school_name, p.email, count(l.*) as sms_sent
from sms_log l
join profiles p on p.id = l.owner_id
where l.status = 'sent'
  and l.created_at >= date_trunc('month', now())
group by p.school_name, p.email
order by sms_sent desc;
```
This gives you exactly how many SMS each school used this month — multiply by
your per-SMS rate (plus your subscription fee) to generate their invoice.

## D. Suggested pricing structure (starting point — adjust to your market)
- **Monthly subscription** per school (covers software access, support, updates)
- **Per-SMS charge** on top — pass through your SendPK cost + a margin
- Optional: **tiered plans** by student count (e.g. up to 200 students / up to 500 / unlimited)

## E. Offboarding a school
1. Remove their email from `whitelist_emails` (stops future signups if they ever get logged out)
2. Set `profiles.subscription_status = 'suspended'` for their account
3. Their existing data stays safe in the database (in case they resubscribe later) — nothing is deleted automatically

## G. One-time-sale customer (no recurring payment, SMS off, you provide support)

For a school that pays once and never again — you just help them with login/technical
issues going forward, no billing cycle needed.

1. Onboard them normally (steps in section A).
2. Turn their SMS off so it never costs you anything later:
   ```sql
   update profiles set sms_enabled = false where email = 'school@example.com';
   ```
   (Run `supabase/add_sms_toggle.sql` once first if you haven't already — it adds this column.)
3. If they ever come to you with a login problem:
   - **Forgot password** → Supabase Dashboard → Authentication → Users → find their
     email → "Send password recovery" (or set a new password directly)
   - **Account locked / email not confirmed** → same Users screen → click their row →
     manually confirm the email
   - **Wrong school info showing** → Table Editor → `profiles` → find their row → edit directly
4. If they later want SMS turned on (as a paid add-on), flip the same flag to `true`
   and start charging per the section C query, filtered to just their school.

## H. Track which customers are one-time-sale vs subscription
```sql
select email, school_name, sms_enabled, created_at
from profiles
order by created_at desc;
```
`sms_enabled = false` is your quick way to spot the one-time-sale, no-recurring-cost customers.

