# Security Checklist

## What this script locks down
| Risk | Fix applied |
|---|---|
| School A reads/edits School B's students, fees, teachers, salaries, transactions | Row Level Security: every row only visible/editable by its `owner_id` |
| A user gives themselves admin access | `profiles.is_admin` can never be changed through the app — only you, manually, via Supabase Table Editor |
| Anyone reads the full list of whitelisted school emails | Direct table access blocked; only two narrow, controlled functions can touch it |
| SendPK SMS API key stolen from browser | Already fixed earlier — key lives only in the `send-sms` Edge Function, never sent to any browser |
| Someone inserts fake "SMS sent" log entries to dodge billing | Only the Edge Function (using the service role key, server-side) may insert into `sms_log` |

## How to apply it
1. Supabase Dashboard → SQL Editor → New Query
2. Paste the contents of `supabase/harden_security.sql`
3. Run it

## How to verify it actually worked
1. Create two throwaway test accounts (two different schools)
2. Add a student under Account A
3. Log out, log into Account B
4. Confirm Account B's student list is empty / does not show Account A's student
5. Open browser DevTools → Network tab while using Account B, and check that no request ever returns Account A's data

## Making someone an admin (yourself)
Since the app can no longer do this for you (on purpose — that's the security fix):
1. Supabase Dashboard → Table Editor → `profiles`
2. Find their row → set `is_admin` to `true` → Save

## Ongoing habits worth keeping
- Never put the `service_role` key anywhere in `index.html` or any file that ships to a browser — it belongs only inside Edge Functions / server secrets.
- Every new table you add later needs `enable row level security` + an `owner_id`-based policy, or it will be wide open by default.
- Rotate your SendPK API key if you ever suspect it leaked (old dashboards, screen shares, etc.).
